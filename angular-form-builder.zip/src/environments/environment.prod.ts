export const environment = {
  production: true,
  defaultLanguage: 'en-US',
  supportedLanguages: ['vi-VN', 'en-US', 'ja-JP'],
};
