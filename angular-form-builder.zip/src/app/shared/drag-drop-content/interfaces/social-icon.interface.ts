export interface SocialIconInterface {
  id: string;
  name: string;
  icon: string;
  img_link: string;
  link_to?: string;
}
