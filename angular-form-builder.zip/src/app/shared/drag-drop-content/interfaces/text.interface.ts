export interface TextInterface {
  content: string;  
  text_color: null | string;  
  line_height: number;
  font_family: string;
}
