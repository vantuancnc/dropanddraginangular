export interface InputInterface {
  label: string;
  field_name: null | string;
  is_required: boolean;
  show_label: boolean;
  placeholder_text: string;
}
