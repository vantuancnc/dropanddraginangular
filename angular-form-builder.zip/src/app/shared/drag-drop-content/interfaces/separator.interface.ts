export interface SeparatorInterface {  
  border_style: string;
  border_color: string;
  border_width: number;
}
