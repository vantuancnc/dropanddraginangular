export interface SpacerInterface {  
  height: number;  
}
