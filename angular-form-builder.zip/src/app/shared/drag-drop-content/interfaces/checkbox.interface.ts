export interface CheckboxInterface {
  label: string;
  field_name: null | string;
  is_required: boolean;
}
